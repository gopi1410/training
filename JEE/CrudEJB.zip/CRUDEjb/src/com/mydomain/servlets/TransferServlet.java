package com.mydomain.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mydomain.ejb.UserManagerLocal;

@WebServlet("/TransferServlet")
public class TransferServlet extends HttpServlet {
	
	@EJB
	UserManagerLocal userManager;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			String[] idStrArr = request.getParameterValues("selectedIds");
			userManager.transferUser(Integer.parseInt(idStrArr[0]));
			response.sendRedirect("listServlet");
		}catch(Exception e){
			throw new ServletException(e);
		}
	}
}
