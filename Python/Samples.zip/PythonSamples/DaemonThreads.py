import threading
 
class MyThread (threading.Thread):
    def run(self):
        for i in range(100000):
            print("Value of i ",i);
  
thread1 = MyThread()
thread1.daemon = True
thread1.start()
print("Started thread");
# for i in range(100000):
#     print("Value of i ********** ",str(i));
