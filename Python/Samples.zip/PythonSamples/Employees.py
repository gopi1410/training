class Employee:
    def __init__(self,name,eid):
        self.name = name
        self.id = eid
        
    def __str__(self):
        s = "Name: {} and ID: {}".format(self.name,self.id)
        return s
        
    def print_employee(self):
        print("Name: {} and ID: {}".format(self.name,self.id))
  
def print_employee(employee):
        print("Name: {} and ID: {}".format(employee.name,employee.id))      
        
emps = []

while True:
    print("1. Add employee")
    print("2. Print Employees")
    choice = int(input("Enter choice: "))
    if choice==1 :
        name = input("Enter name:")
        eid = input("Enter ID:")
        e = Employee(name,eid)
        emps.append(e)
    else:
        for emp in emps:
            print(emp)
        