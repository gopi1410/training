class PhoneRecord:

    'Phone book record'

    def __init__(self, name, number, addr):

        self.name = name

        self.number = number

        self.addr = addr


    def show_entry(self):

        print("{} listed with number {}, address {}".format(self.name, self.number, self.addr))
