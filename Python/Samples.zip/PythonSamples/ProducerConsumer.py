from threading import Condition
import threading

cv = Condition()
data_list = []
class MyProducerThread (threading.Thread):
    def run(self):
        cv.acquire()       
        while True:
            text = input("Enter text: ")
            data_list.append(text)
            cv.notify()
            cv.wait()
            print("Notified...")
        cv.release()
             
class MyConsumerThread (threading.Thread):
    def run(self):
        cv.acquire()       
        while True:
            while len(data_list)==0 :
                print("Waiting...")
                cv.wait()    
            print("Processing...")
            data = data_list[0]
            del data_list[0:len(data_list)]
            print("Consumer got data: ",data)
            cv.notify()
        cv.release()
 
thread1 = MyConsumerThread()
thread1.start()
thread2 = MyProducerThread()
thread2.start()