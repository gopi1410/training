"""for s in sys.path:
    print(s)

print("-----------------------------------------------------")

flights = ['9W811','IA414', '9W522']
print(len(flights))
flights.append('MH213')
flights.append(5)
flights.extend('QA400') #Treats this as an array of chars
flights.extend(['SL419'])
flights.insert(1,'9w811')
flights.remove('9w811')
print(flights.pop())
print(flights)

for flight in flights:
    k=10
    print("Flight = "+str(flight))
print("value of k = "+str(k))
    
flights.insert(2,['QA300','QA303'])
for flight in flights:
    print("Flight = "+str(flight))

print(isinstance(flights, list))
print(type(flights) == list)
print(flights.__class__ == list)
    #print(True)
print

s1 = "abc"
s2 = s1
s1 = s1+"xyz"
print(s1)
print(s2)

k1 = 10.5
k2 = k1
k1=k1+15.2
print(k1)
print(k2)

x = str
print ("Sachin "+x(10)+"dulkar")

def getLength(arr=[], arr2=[]):
    arr.extend(arr2)
    return len(arr)


print(getLength(flights,"Hello"))
print(flights)



print(os.getcwd())"""

import datetime
import math
from queue import Queue
import sys
from test.regrtest import multiprocessing


# def myfunction( var1, var2="lmn", var3="xyz"):
#     print("{} {} {}".format(var1, var2, var3))
#     
#     
# myfunction ("abc",var3="xyz")
"""import os
with open(os.getcwd()+"/Scratchpad.py") as f, open(os.getcwd()+"/ScratchpadCopy.py", "w") as f2 :
    try:
        for line in f:
            print(line)
        print("##########################")
        f.seek(0)
        while True:
            line = f.readline();
            if not line:
                break
            else:
                print(line, end='')
                print(line, file=f2, end='')
                #f2.writelines(line)
    except:
        pass
print(f.closed)"""

# try:
#     while True:
#         print("Looping")
# except KeyboardInterrupt as e:
#     print (e)
               
"""tup1 = ('Kelly', 'Perry', 1997, 2000);
tup2 = (1, 2, 3, 4, 5 );
tup3 = "a", "b", "c", "d";

cars = "Hello";
strTuple = tuple(cars)
print(strTuple)

(a,b,c) = ['Maruti','Fiat','Hyundai']
print(a)

(x,y) = "Maruthi:swift".split(":")
print(y)"""

# class Employee:
#     'Common base class for all employees'
#     empCount = 0
# 
#     def __init__(self, name, salary):
#         self.name = name
#         self.salary = salary
#         Employee.empCount += 1
#    
#     def displayCount(self):
#         print ("Total Employee %d" % Employee.empCount)
# 
#     def displayEmployee(self):
#         print ("Name : ", self.name,  ", Salary: ", self.salary)
# 
# print ("Employee.__doc__:", Employee.__doc__)
# print ("Employee.__name__:", Employee.__name__)
# print ("Employee.__module__:", Employee.__module__)
# print ("Employee.__bases__:", Employee.__bases__)
# print ("Employee.__dict__:", Employee.__dict__)   
# print("Done")
# 
# class Parent:        # define parent class
#     parentAttr = 100
#     def __init__(self):
#         print( "Calling parent constructor")
# 
#     def parentMethod(self):
#         print ('Calling parent method')
# 
#     def setAttr(self, attr):
#         Parent.parentAttr = attr
# 
#     def getAttr(self):
#         print ("Parent attribute :", Parent.parentAttr)
# 
# class Child(Parent): # define child class
#     def __init__(self):
#         print ("Calling child constructor")
# 
#     def childMethod(self):
#         print ('Calling child method')
# 
# c = Child()          # instance of child
# c.childMethod()      # child calls its method
# c.parentMethod()     # calls parent's method
# c.setAttr(200)       # again call parent's method
# c.getAttr()          # again call parent's method
# 
# S = [x**2 for x in range(10)]
# V = [2**i for i in range(13)]
# M = [x for x in S if x % 2 == 0]
# print (S); print (V); print (M)
#   
#  
# noprimes = []
# primes = []
# for i in range(2, 8):
#     for j in range(i*2, 50, i):
#         noprimes.append(j)
#  
# for x in range(2,50):
#     if x not in noprimes:
#         primes.append(x)
#  
# print(primes)
#  
# noprimes = [j for i in range(2, 8) for j in range(i*2, 50, i)]
# primes = [x for x in range(2, 50) if x not in noprimes]
# print (primes)
#  
# words = 'The quick brown fox jumps over the lazy dog'.split()
# stuff = []
# for word in words:
#     temp = [word.upper(), word.lower(), len(word)]
#     stuff.append(temp)
# print(stuff)
#  
# words = 'The quick brown fox jumps over the lazy dog'.split()
# stuff = [[w.upper(), w.lower(), len(w)] for w in words]
# print(stuff)
#  
# stuff = map(lambda w: [w.upper(), w.lower(), len(w)], words)
# for i in stuff:
#     print(i, end=' ')
#  
# print()
#      
# f = lambda x, y : x + y
# print(f(1,1))

# temp = [32,35,39,27]
# farh = []
# for T in temp:
#     f = ((float(9)/5)*T + 32)
#     farh.append(f)
# print(farh)
# 
# farh = map(lambda T: ((float(9)/5)*T + 32), temp)
# for f in farh:
#     print(f)
# 
# def farhaniet(T):
#     return ((float(9)/5)*T + 32)
# 
# farh = map(farhaniet, temp)
# for f in farh:
#     print(f)
# 
# even = []
# for i in range(100):
#     if not i % 2:
#         even.append(i)
# print(even)
# 
# even = filter(lambda x: not x%2, range(100))
# print(even)
# for e in even:
#     print (e,end=' ')
# print()   
# 
# sum_=0
# for i in range(100):
#     sum_+=i
# print (sum_)
# 
# from _functools import reduce
# sum_ = reduce(lambda x,y:x+y,range(100))
# print("Sum2: "+str(sum_))
# 
# 
# for s in sys.path:
#     print(s)
 
#--------------------------------------------------THREADING------------------------------------------------
# from threading import Thread, Condition
# import threading
#  
# class MyThread (threading.Thread):
#      def run(self):
#          for i in range(100000):
#              print("Value of i ",i);
#   
# thread1 = MyThread()
# thread1.setDaemon(True)
# thread1.start()
# print("Started thread");
# for i in range(100000):
#     print("Value of i ********** ",str(i));


# k=[]
# k.append(0)
# # confirms to the context managemnt protocol
# cv = Condition()
# 
# class MyThread (threading.Thread):
#     def run(self):
#         for i in range(100000):
#             cv.acquire()
#             k[0] = i
#             print("Value of i = ",k)
#             if k[0]!=i:
#                 print("This cant print################################")
#             cv.release()
#  
# thread1 = MyThread()
# thread1.start()
# print("Started thread");
# for j in range(100000):
#     cv.acquire()
#     k[0] = j
#     print("********* Value of j = ",j)
#     if k[0]!=j:
#         print("This cant print################################")
#     cv.release()

        
# cv = Condition()
# data_list = []
# class MyProducerThread (threading.Thread):
#     def run(self):
#         cv.acquire()       
#         while True:
#             text = input("Enter text: ")
#             data_list.append(text)
#             cv.notify()
#             cv.wait()
#             print("Notified...")
#         cv.release()
#             
# class MyConsumerThread (threading.Thread):
#     def run(self):
#         cv.acquire()       
#         while True:
#             while len(data_list)==0 :
#                 print("Waiting...")
#                 cv.wait()    
#             print("Processing...")
#             data = data_list[0]
#             del data_list[0:len(data_list)]
#             print("Consumer got data: ",data)
#             cv.notify()
#         cv.release()
# 
# thread1 = MyConsumerThread()
# thread1.start()
# thread2 = MyProducerThread()
# thread2.start()

#ThreadPool    
# def getRunner(runner_id):
#     def run() :
#         for i in range(1000):
#             print(runner_id," in Thread: ",threading.get_ident());
#     return run
# 
# 
# 
# class ThreadPool:
#     def __init__(self,N) :
#         self.workerQueue = Queue()
#         self.workerThreads = [None] * N
#         #Start N Threads and keep them running
#         for i in range(N) :
#             self.workerThreads[i] = self.Worker(self.workerQueue)
#             self.workerThreads[i].start()
#  
#     def addTask(self,runner):
#         try :
#             self.workerQueue.put(runner)
#         except: 
#             pass
#         
#     class Worker(Thread):
#         def __init__(self, workerQueue):
#             Thread.__init__(self)
#             self.workerQueue = workerQueue
#             
#         def run(self):
#             while True :
#                 runner = self.workerQueue.get()
#                 runner()
#   
# tp = ThreadPool(5);
# for i in range(100) :
#     tp.addTask(getRunner(i));


#print("Sin: {} and Method call {} millisecods".format(k,duration.microseconds/100))


# class Employee:
#     'Carries employee details'
#     emp_count = 0  # this is like static variable
# 
# #     def __str__(self):
# #         return self.name
#     
#     def __repr__(self):
#         return self.name+":"+self.number
#     
#     def __init__(self, name, number):
#         self.name = name
#         self.number = number
#         Employee.emp_count += 1
#    
#     def displayCount(self):
#         print ("Total Employee %d" % Employee.emp_count)
# 
#     def displayEmployee(self):
#         print ("Name : ", self.name, ", Number: ", self.number)
#       
# emp1 = Employee('Manish','9845343334')
# emp2 = Employee('Jack','9845393334')
# 
# emp1.displayEmployee()
# emp2.displayEmployee()
# print ("Total Employee %d" % Employee.emp_count)
# 
# emp1.age = 7  # Add an 'age' attribute.
# emp1.age = 8  # Modify 'age' attribute.
# del emp1.age  # Delete 'age' attribute.
# 
# hasattr(emp1, 'age')    # Returns true if 'age' attribute exists
# #getattr(emp1, 'age')    # Returns value of 'age' attribute
# setattr(emp1, 'age', 8) # Set attribute 'age' at 8
# delattr(emp1, 'age')    # Delete attribute 'age'
# 
# print ("Employee.__doc__:", Employee.__doc__)
# print ("Employee.__name__:", Employee.__name__)
# print ("Employee.__module__:", Employee.__module__)
# print ("Employee.__bases__:", Employee.__bases__)
# print ("Employee.__dict__:", Employee.__dict__)
# print ("emp.__dict__:", emp1.__dict__)
# 
# 
# def add():
#     counter=0
#     counter += 1
#     print(counter)
#     
# add()
# add()
# 
# def get_add_fn():
#     counter = 0
#     def add(): 
#         nonlocal counter
#         counter += 1
#         print(counter)
#         return counter
#     return add
# 
# add = get_add_fn()
# add()
# add()
# 
# def notifyUser(email) :
#     def inner_notify(text) :
#         print("Sending '"+text+"' to "+email)
#     return inner_notify
# 
# notifyWill = notifyUser('wberger@lo.com')
# notifyKelly = notifyUser('kperry@lo.com')
# 
# notifyWill("Hello, you have a new join request")
# notifyKelly("Hello you are late to work!")
# 
# 
# def make_pretty(func):
#     def inner():
#         print("I got decorated")
#         func()
#     return inner
# 
# @make_pretty
# def ordinary():
#     print("I am ordinary")
# 
# pretty = make_pretty(ordinary)
# pretty()
# 
# ordinary = make_pretty(ordinary)
# ordinary()
# 
# def smart_divide(func):
#     def inner(a,b):
#         print("I am going to divide",a,"and",b)
#         if b == 0:
#             print("Whoops! cannot divide")
#             return
# 
#         return func(a,b)
#     return inner
# 
# @smart_divide
# def divide(a,b):
#     return a/b
# 
# divide(10, 0)
# 
# def star(func):
#     def inner(*args, **kwargs):
#         print("*" * 80)
#         func(*args, **kwargs)
#         print("*" * 80)
#     return inner
# 
# def percent(func):
#     def inner(*args, **kwargs):
#         print("%" * 80)
#         func(*args, **kwargs)
#         print("%" * 80)
#     return inner
# 
# @star
# @percent
# def printer(msg):
#     print(msg)
#     
# printer("Decorated message")

# import multiprocessing as mp 
# from multiprocessing import Pool
# 
# def f(x):
#     return x*x
# 
# 
# print(__name__)
# # if __name__ == '__main__':
# #     mp.set_start_method('forkserver')
# # start 4 worker processes
# with Pool(processes=4) as pool:
# 
#     # print "[0, 1, 4,..., 81]"
#     print(pool.map(f, range(10)))
#     
#     # print same numbers in arbitrary order
#     for i in pool.imap_unordered(f, range(10)):
#         print(i)
#         
#     # evaluate "f(10)" asynchronously
#     res = pool.apply_async(f, [10])
#     print(res.get(timeout=1)) 
    
# import unittest
# 
# class TestStringMethods(unittest.TestCase):
# 
#   def test_upper(self):
#       self.assertEqual('foo'.upper(), 'FOO')
# 
#   def test_isupper(self):
#       self.assertTrue('FOO'.isupper())
#       self.assertFalse('Foo'.isupper())
# 
#   def test_split(self):
#       s = 'hello world'
#       self.assertEqual(s.split(), ['hello', 'world'])
#       # check that s.split fails when the separator is not a string
#       with self.assertRaises(TypeError):
#           s.split(2)
# 
# if __name__ == '__main__':
#     unittest.main()    

# file=None
# def function1():
#     global file
#     file = open("Employees.py")
#     
# def function2():
#     function1()
#     
# def function3():
#     function2()
#   
# try:  
#     function3()
#     for line in file:
#         print(line, end='')
#     x = 5/0
# except FileNotFoundError as e:
#     print("File could not be opened. Specify a different file")
# except ZeroDivisionError as z:
#     print("Divide by zero happened...")
# finally:
#     if file:
#         print("Closing the file...")
#         file.close()
# 
# print("Remaining part of the program here")

#----------------------------------------------------------------------------------------

# class Testcaseerror(Exception):
#     def __init__(self, arg):
#         self.arg = arg
#           
# def test_user_create():
#     print("Testing user creation...")
#     db_connection = get_connection()
#     if not db_connection:
#         raise Testcaseerror("Could not connect to database")
#     print("User test case OK")
#   
# def test_user_delete():
#     print("Testing user delete...")
#   
# def test_customer_create():
#     print("Testing customer creation...")
#     print("Customer created ok") 
#   
# def test_customer_delete():
#     print("Testing customer delete...")
#   
# def user_test_suite():
#     try:
#         test_user_create()
#         test_user_delete()
#     except Testcaseerror as e:
#         print("User tests failed") 
#       
# def customer_test_suite():
#     test_customer_create()
#     test_customer_delete()
#       
# def system_test():
#     user_test_suite()
#     customer_test_suite()
#   
#   
# system_test()

S = [x**2 for x in range(10)]
V = [2**i for i in range(13)]
M = [x for x in S if x % 2 == 0]

print(S)
print(V)
print(M)


























