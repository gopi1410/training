from timeit import Timer
import multiprocessing
import math
import threading
 
k=0
def threaded_sin_compute():
    global k
    thread1 = MyThread()
    thread1.start()
    for i in range(5000001,10000000):
        k+=math.sin(i)
    thread1.join()
    #print("Computed sin = ",str(k))
 
class MyThread (threading.Thread):
    def run(self):
        global k
        for i in range(1,5000000):
            k+=math.sin(i)

def normal_sin_compute():
    global k
    for i in range(1,10000000):
        k+=math.sin(i)
  
#if __name__ == "__main__":
t = Timer("threaded_sin_compute()", "from __main__ import threaded_sin_compute")
print("Threaded computation: ",t.timeit(5))

t2 = Timer("normal_sin_compute()", "from __main__ import normal_sin_compute")
print("Normal computation: ",t2.timeit(5))


def multiproc_sin_compute():
    def half_sin_compute1():
        global k
        for i in range(5000001,10000000):
            k+=math.sin(i)
    def half_sin_compute2():
        global k
        for i in range(1,5000001):
            k+=math.sin(i)
    p = multiprocessing.Process(target=half_sin_compute1)
    p2 = multiprocessing.Process(target=half_sin_compute2)
    p.start()
    p2.start()
    p.join()
    p2.join()
     
t3 = Timer("multiproc_sin_compute()", "from __main__ import multiproc_sin_compute")
print("Multiproc computation: ",t3.timeit(5))