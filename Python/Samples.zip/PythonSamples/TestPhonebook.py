import unittest
#from step14 import PhoneRecord

class TestPh(unittest.TestCase):
    
#     def setUp(self):
#         PhoneRecord.pickled_file_name = "test.pic"

    def test_loading(self):
        self.assertTrue(True)
        #records = PhoneRecord.load_from_pickled_file()
        #self.assertEqual(len(records), 4)
        
if __name__ == '__main__':
    unittest.main()    

