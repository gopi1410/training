from threading import Condition
import threading
k=[]
k.append(0)
# confirms to the context managemnt protocol
cv = Condition()
 
class MyThread (threading.Thread):
    def run(self):
        for i in range(100000):
            cv.acquire()
            k[0] = i
            print("Value of i = ",k)
            if k[0]!=i:
                print("This cant print################################")
            cv.release()
  
thread1 = MyThread()
thread1.start()
print("Started thread");
for j in range(100000):
    cv.acquire()
    k[0] = j
    print("********* Value of j = ",j)
    if k[0]!=j:
        print("This cant print################################")
    cv.release()
