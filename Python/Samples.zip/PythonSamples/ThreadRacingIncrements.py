import threading
k=0
 
class MyThread (threading.Thread):
    def run(self):
        global k
        for i in range(1000000):
            k+=1
  
thread1 = MyThread()
thread1.start()
print("Started thread");
for j in range(1000000):
    k+=1
thread1.join()
print("Value of k %d" % k)