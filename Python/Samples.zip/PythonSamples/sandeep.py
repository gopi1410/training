import pickle
from PHModule import PhoneRecord

phonebook = {}

        
rec_count = 0

phonefile = open("Phonebook.pickle", "ab+")
try:

    phonefile.seek(0)

    while(1):

        print("Iteration {}".format(rec_count))

        tmp = pickle.load(phonefile)

        phonebook[tmp.name] = tmp

        rec_count += 1

except EOFError:

    print("Reached end of file after reading {} records. Closing file.".format(rec_count))

    # phonefile.close()

except IOError:

    print("Cannot open file")

# except AttributeError:

#    print("No records in file")

except pickle.UnpicklingError:

    print("No records in file")






def add_entry(a_name="", a_number="", a_addr=""):

    phonebook[a_name] = PhoneRecord(a_name, a_number, a_addr)

    print("Added [{}, {}, {}] to phonebook".format(a_name, a_number, a_addr))

    return


def delete_entry(d_name=""):

    if not d_name in phonebook:

        print(d_name, "is not listed in phonebook")

    else:

        del phonebook[d_name]

        print("Removed {} from phonebook".format(d_name))

    return


def search_entry(s_name=""):

    if not s_name in phonebook:

        print(s_name, "is not listed in phonebook")

    else:

        phonebook[s_name].show_entry()


def get_choice():

    choice = "3"

    n_choice = int(choice)


    print("\nPress 1 to add entry")

    print("Press 2 to delete entry")

    print("Press 3 to search entry")

    print("Press 4 to exit")


    n_choice = int(input())

    return (n_choice)


user_opt = 5


# while (user_opt <= 0) or (user_opt > 4):

while (1):

    user_opt = get_choice()


    if  user_opt == 1:

        name = input("Enter name: ")

        num = input("Enter number: ")

        addr = input("Enter address: ")

        add_entry(name, num, addr)

    elif user_opt == 2:

        name = input("Enter name: ")

        delete_entry(name)

    elif user_opt == 3:

        name = input("Enter name: ")

        search_entry(name)

    elif user_opt == 4:

        phonefile.seek(0)

        for i in phonebook:

            pickle.dump(phonebook[i], phonefile)

        phonefile.close()

        exit()

    else:

        print("Invalid choice. Try again")
