from distutils.core import setup

setup(name='MyModule',
      version='1.0',
      description='My Module',
      author='Maruthi',
      author_email='maruthi@leviossa.com',
      url='http://www.leviossa.com/',
      py_modules=['mymodule']
     )