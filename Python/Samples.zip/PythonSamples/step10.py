#----------------------------
# Use of iterators to work with the picked file
#----------------------------

import pickle
from pickle import UnpicklingError

phone_book = {}

class PhoneRecord:
    pickled_file_name = "phonebook.pic"
    
    @staticmethod
    def load_from_pickled_file() :
        phone_book_list = []
        with open(PhoneRecord.pickled_file_name, mode='rb') as phone_book_file:
            while True:
                try:
                    phone_record = pickle.load(phone_book_file)
                    phone_book_list.append(phone_record)
                except (UnpicklingError, EOFError):
                    break
        return phone_book_list
    
    @staticmethod
    def save_pickled(phone_book_list):
        with open(PhoneRecord.pickled_file_name, mode='wb+') as phone_book_file:
            for phone_book in phone_book_list:
                pickle.dump(phone_book,phone_book_file)
    
    def __init__(self,name,number,address) :
        self.name = name
        self.number = number
        self.address = address

class PhoneRecordIterator:     
    def __init__(self,pickled_file_name="phonebook.pic") :
        self.pickled_file_name = pickled_file_name
           
    def __iter__(self):
        self.file = open(self.pickled_file_name, mode='rb')
        return self

    def __next__(self):
        try:
            phone_record = pickle.load(self.file)
            return phone_record
        except (UnpicklingError, EOFError) as e:
            print("Error : {} {}".format(e.__class__,str(e)))
            self.file.close()
            raise StopIteration
        

def add_phone_book_entry():
    entryInput = input("Enter name, number and address comma separated: ")
    nameNumberAddress = entryInput.split(sep=",")
    phoneRecord = PhoneRecord(nameNumberAddress[0],nameNumberAddress[1],nameNumberAddress[2])
    phone_book[nameNumberAddress[0]] = phoneRecord

def lookup_phone_book_entry():
    name = input("Enter name to lookup: ")
    if not name in phone_book:
        print("{} does not exist in the phonebook".format(name))
    else:
        numberAdress = phone_book[name]
        print("Number for {} is {}. And address: {}".format(name,numberAdress.number,numberAdress.address))

def exit_prog():
    update_phone_book()
    quit()
    
def print_phone_book():
    phone_iter = PhoneRecordIterator()
    for phone_record in phone_iter:
        print("Number for {} is {}. And address: {}".format(phone_record.name,phone_record.number,phone_record.address))

def load_phone_book_from_file():
    phone_book_list = PhoneRecord.load_from_pickled_file()
    for phone_record in phone_book_list:
        phone_book[phone_record.name] = phone_record
        
def update_phone_book():
    phone_book_list = []
    for name in phone_book:
        phone_book_list.append(phone_book[name])
    PhoneRecord.save_pickled(phone_book_list)
        

load_phone_book_from_file()

while True:
    print("Choose an action:")
    print("1. Add a phone book entry")
    print("2. Lookup a phone book entry")
    print("3. Print phone book")
    print("4. Exit")
    choice = input("Enter choice: ")
    choice = int(choice)
    if choice==1:
        add_phone_book_entry()
    elif choice==2:
        lookup_phone_book_entry()
    elif choice==3:
        print_phone_book()
    elif choice==4:
        exit_prog()