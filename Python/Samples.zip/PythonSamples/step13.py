#----------------------------
# User defined exceptions and exception wrapping
#----------------------------

import pickle
from pickle import UnpicklingError
import re

phone_book = {}

class PhonebookException(Exception):
    def __init__(self, arg):
        self.arg = arg
      
class PhoneRecord:
    pickled_file_name = "phonebosok.pic"
    
    def __str__(self):
        return "Number for {} is {}. And address: {}".format(self.name,self.number,self.address)
    
    @staticmethod
    def load_from_pickled_file() :
        try:
            phone_book_list = []
            with open(PhoneRecord.pickled_file_name, mode='rb') as phone_book_file:
                while True:
                    try:
                        phone_record = pickle.load(phone_book_file)
                        phone_book_list.append(phone_record)
                    except (UnpicklingError, EOFError):
                        break
            return phone_book_list
        except Exception as e:
            raise PhonebookException("could not read phonebook") from e
    
    @staticmethod
    def save_pickled(phone_book_list):
        with open(PhoneRecord.pickled_file_name, mode='wb+') as phone_book_file:
            for phone_book in phone_book_list:
                pickle.dump(phone_book,phone_book_file)
    
    def __init__(self,name,number,address) :
        self.name = name
        self.number = number
        self.address = address


def phone_records_generator():
    print("Generator started")
    file = open("phonebook.pic", mode='rb')
    while True:
        try:
            phone_record = pickle.load(file)
            print("Yeilding a record from generator")
            yield phone_record
        except (UnpicklingError, EOFError) as e:
            file.close()
            break
    
def add_phone_book_entry():
    entryInput = input("Enter name, number and address comma separated: ")
    nameNumberAddress = entryInput.split(sep=",")
    phoneRecord = PhoneRecord(nameNumberAddress[0],nameNumberAddress[1],nameNumberAddress[2])
    phone_book[nameNumberAddress[0]] = phoneRecord

def lookup_phone_book_entry():
    name = input("Enter name to lookup: ")
    if not name in phone_book:
        print("{} does not exist in the phonebook".format(name))
    else:
        phone_record = phone_book[name]
        print(phone_record)

def exit_prog():
    update_phone_book()
    quit()
    
def print_phone_book():
    phone_gen = phone_records_generator()
    print("Going to iterate over generated values")
    #phone_iter = phone_gen.__iter__()
    #phone_record = phone_iter.__next__()
    #print(str(phone_record))
    for phone_record in phone_gen:
        print(phone_record)

def search_phone_book():
    search_string = input("Enter name or part of a name to search: ")
    for name in phone_book:
        matchObj = re.match(".*{}.*".format(search_string), name)
        if matchObj:
            print(phone_book[name])
    
options = {1: add_phone_book_entry, 2:lookup_phone_book_entry, 3: print_phone_book, 4:search_phone_book, 5:exit_prog}

def load_phone_book_from_file():
    phone_book_list = PhoneRecord.load_from_pickled_file()
    for phone_record in phone_book_list:
        phone_book[phone_record.name] = phone_record
        
def update_phone_book():
    phone_book_list = []
    for name in phone_book:
        phone_book_list.append(phone_book[name])
    PhoneRecord.save_pickled(phone_book_list)
        

load_phone_book_from_file()

while True:
    print("Choose an action:")
    print("1. Add a phone book entry")
    print("2. Lookup a phone book entry")
    print("3. Print phone book")
    print("4. Search phone book")
    print("5. Exit")
    choice = input("Enter choice: ")
    choice = int(choice)
    options[choice]()