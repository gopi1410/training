#----------------------------
# Add the synchronous loop based copy command and measure the time it takes to copy a bunch of files
#----------------------------
import os
    
class Const:
    class ConstError(TypeError): 
        pass
    
    def __setattr__(self,name,value):
        if name in self.__dict__:
            raise const.ConstError("Can't rebind const {}".format(name))
        self.__dict__[name]=value
   
const = Const()
const.unknown_command = "unknown_command"

class CommandError(Exception):
    """Used to indicate errors in any kind of command processing"""
    def __init__(self, arg):
        self.arg = arg

class CommandFactory:
    """A factory of command objects"""
    
    def __init__(self):
        self.commands = {}
        self.commands["ls"] = ListCommand
        self.commands["pwd"] = PwdCommand
        self.commands["exit"] = QuitCommand
        self.commands["cd"] = ChdirCommand
        self.commands["cp"] = CopyCommand
        self.commands[const.unknown_command] = UnknownCommand
        
    def get_command(self,command):
        #extract first word that will be the command name
        command_name = command.split(sep=" ")[0]
        if command_name in self.commands :
            return self.commands[command_name](command)
        else:
            return self.commands[const.unknown_command](command)
        
class Command:
    """Command interface that establishes a contract for all commands"""
    def __init__(self, command):
        raise NotImplementedError( "Cannot create an instance of the interface" )
    
    def execute(self):
        raise NotImplementedError( "{} should implement the execute method".format(self.__class__) )
        
class ListCommand(Command):
    """Implements the directory listing command"""
    
    def __init__(self,command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >1 :
            self.folder_path = command.split(sep=" ")[1]
        else:
            self.folder_path="."
        
    def execute(self):
        files = os.listdir(path=self.folder_path)
        for file_ in files:
            print(file_)
    
class PwdCommand(Command):
    """Implements the present working directory command"""
    
    def __init__(self, param):
        #this command has no data
        pass
    
    def execute(self):
        print(os.getcwd())

class QuitCommand(Command):
    """Implements the present working directory command"""
    
    def __init__(self, param):
        #this command has no data
        pass
    
    def execute(self):
        quit()

class UnknownCommand(Command):
    """Just prints unknown command"""
    
    def __init__(self, param):
        #this command has no data
        pass
    
    def execute(self):
        print("Unknown command")
        
class ChdirCommand(Command):
    """Implements the present working directory command"""
    
    def __init__(self, command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >1 :
            self.folder_path = command.split(sep=" ")[1]
        else:
            self.folder_path="."
    
    def execute(self):
        os.chdir(self.folder_path)
    
import re    
import datetime

class CopyCommand(Command):
    """Implements the a command to copy one or more files"""
    
    def __init__(self, command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >2 :
            self.source = command.split(sep=" ")[1]
            self.dest_folder = command.split(sep=" ")[2]
        else:
            raise CommandError("invalid cp syntax. Only works in current directory. Source file pattern can be regex. Usage: cp sourceFilePattern destFolder")
    
    def execute(self):
        files = os.listdir()
        start = datetime.datetime.now()
        file_count = 0
        for file_ in files:
            if os.path.isdir(file_): continue
            match_obj = re.match(self.source,file_)
            if match_obj:
                dest_file = self.dest_folder+"/"+file_
                with open(file_, mode='rb') as source_file, open(dest_file, mode='wb') as dest_file :
                    while True:
                        b = source_file.read()
                        if b:
                            dest_file.write(b)
                        else:
                            file_count+=1
                            break
        end = datetime.datetime.now()
        duration = end - start
        print("Copied {} files in {} microseconds".format(file_count,duration.microseconds))

while True:
    command = input("> ")
    cf = CommandFactory()
    command = cf.get_command(command)
    command.execute()