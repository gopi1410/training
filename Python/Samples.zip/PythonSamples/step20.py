#----------------------------
# Multithreaded copy command
#----------------------------
import os
import gzip
from _functools import reduce
from queue import Queue
from threading import Thread

    
class Const:
    class ConstError(TypeError): 
        pass
    
    def __setattr__(self,name,value):
        if name in self.__dict__:
            raise const.ConstError("Can't rebind const {}".format(name))
        self.__dict__[name]=value
   
const = Const()
const.unknown_command = "unknown_command"

class ContextFolder(object):
    def __init__(self,folder):
        self.folder = folder
        
    #Presense of the __call__ method makes this object a callable. Means an instance of the object x can be used as x(original_func)
    def __call__(self, original_func):
        decorator_self = self
        def decorator_function( *args, **kwargs):
            print("setting context dir...")
            backup = os.getcwd()
            os.chdir(decorator_self.folder)
            original_func(*args,**kwargs)
            os.chdir(backup)
        return decorator_function
    

class CommandError(Exception):
    """Used to indicate errors in any kind of command processing"""
    def __init__(self, arg):
        self.arg = arg

def ListCommandClosure(command, commands_dict):
    """Implements the directory listing command"""
    
    @ContextFolder("/Users/maruthir")
    def execute():
        #assuming second word would be the path
        if len(command.split(sep=" ")) >1 :
            folder_path = command.split(sep=" ")[1]
        else:
            folder_path="."
        files = os.listdir(path=folder_path)
        for file_ in files:
            print(file_)
    return execute

def ListRecursiveCommandClosure(command, commands_dict):
    """Implements the directory listing recursive command"""
    
    def execute ():
        #assuming second word would be the path
        if len(command.split(sep=" ")) >1 :
            folder_path = command.split(sep=" ")[1]
        else:
            folder_path="."
        files = os.listdir(path=folder_path)
        for file_ in files:
            if os.path.isdir(file_):
                print("DIR >>> ",file_) 
                commands_dict["ls"]("ls {}/{}".format(folder_path,file_),commands_dict)()
                print("<<< END DIR")
            else:
                print(file_)
    return execute

def get_command(command):
    commands = {"ls" : ListCommandClosure, "lsr" : ListRecursiveCommandClosure}
    command_name = command.split(sep=" ")[0]
    if command_name in commands :
        return commands[command_name](command,commands)

#--------------------------------------------------------------------------------
    
class CommandFactory:
    """A factory of command objects"""
    
    def __init__(self):
        self.commands = {}
        self.commands["ls"] = ListCommand
        self.commands["pwd"] = PwdCommand
        self.commands["exit"] = QuitCommand
        self.commands["cd"] = ChdirCommand
        self.commands["cp"] = CopyCommand
        self.commands["tgzip"] = ThreadedGzipCommand
        self.commands["gzip"] = GzipCommand
        self.commands[const.unknown_command] = UnknownCommand
        
    def get_command(self,command):
        #extract first word that will be the command name
        command_name = command.split(sep=" ")[0]
        if command_name in self.commands :
            return self.commands[command_name](command)
        else:
            return self.commands[const.unknown_command](command)
        
class Command:
    """Command interface that establishes a contract for all commands"""
    def __init__(self, command):
        raise NotImplementedError( "Cannot create an instance of the interface" )
    
    def execute(self):
        raise NotImplementedError( "{} should implement the execute method".format(self.__class__) )
        
class ListCommand(Command):
    """Implements the directory listing command"""
    
    def __init__(self,command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >1 :
            self.folder_path = command.split(sep=" ")[1]
        else:
            self.folder_path="."
        
    def execute(self):
        files = os.listdir(path=self.folder_path)
        for file_ in files:
            print(file_)

class PwdCommand(Command):
    """Implements the present working directory command"""
    
    def __init__(self, param):
        #this command has no data
        pass
    
    def execute(self):
        print(os.getcwd())

class QuitCommand(Command):
    """Implements the present working directory command"""
    
    def __init__(self, param):
        #this command has no data
        pass
    
    def execute(self):
        quit()

class UnknownCommand(Command):
    """Just prints unknown command"""
    
    def __init__(self, param):
        #this command has no data
        pass
    
    def execute(self):
        print("Unknown command")
        
class ChdirCommand(Command):
    """Implements the present working directory command"""
    
    def __init__(self, command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >1 :
            self.folder_path = command.split(sep=" ")[1]
        else:
            self.folder_path="."
    
    def execute(self):
        os.chdir(self.folder_path)
    
import re    
import datetime

def log_time(func):
    def inner(*args, **kwargs):
        start = datetime.datetime.now()
        retval = func(*args, **kwargs)
        end = datetime.datetime.now()
        duration = end - start
        print("Method call {} microseconds".format(duration.microseconds))
        return retval
    return inner

class CopyCommand(Command):
    """Implements the a command to copy one or more files"""
    
    def __init__(self, command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >2 :
            self.source = command.split(sep=" ")[1]
            self.dest_folder = command.split(sep=" ")[2]
        else:
            raise CommandError("invalid cp syntax. Only works in current directory. Source file pattern can be regex. Usage: cp sourceFilePattern destFolder")
    
    @log_time
    def execute(self):
        files = os.listdir()
        
        file_count = 0
        for file_ in files:
            if os.path.isdir(file_): continue
            match_obj = re.match(self.source,file_)
            if match_obj:
                dest_file = self.dest_folder+"/"+file_
                with open(file_, mode='rb') as source_file, open(dest_file, mode='wb') as dest_file :
                    while True:
                        b = source_file.read()
                        if b:
                            dest_file.write(b)
                        else:
                            file_count+=1
                            break
        print("Copied {} files".format(file_count))
        
class CompressorThread(Thread):
    def __init__(self,file_name):
        Thread.__init__(self)
        self.file_name = file_name
    
    def run(self):
        dest_file_name = os.getcwd()+"/temp/"+self.file_name+".gz"
        #print("Compressing file: {} to {}".format(source_file_name,dest_file_name))
        with open(self.file_name, mode='rb') as source_file, gzip.open(dest_file_name, 'wb') as dest_file :
            dest_file.writelines(source_file)        

class ThreadedGzipCommand(Command):
    """Implements the a command to gzip one or more files"""
    
    def __init__(self, command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >2 :
            self.source = command.split(sep=" ")[1]
            self.dest_folder = command.split(sep=" ")[2]
        else:
            raise CommandError("invalid cp syntax. Only works in current directory. Source file pattern can be regex. Usage: cp sourceFilePattern destFolder")
    
    @log_time
    def execute(self):
            
        files = os.listdir()
        files_for_compress = filter(get_filter_function(self.source),files)
        threads = []
        for file_ in files_for_compress:
            cp = CompressorThread(file_)
            cp.start()
            threads.append(cp)
            
        for th in threads:
            th.join()

class GzipCommand(Command):
    """Implements the a command to gzip one or more files"""
    
    def __init__(self, command):
        #assuming second word would be the path
        if len(command.split(sep=" ")) >2 :
            self.source = command.split(sep=" ")[1]
            self.dest_folder = command.split(sep=" ")[2]
        else:
            raise CommandError("invalid cp syntax. Only works in current directory. Source file pattern can be regex. Usage: cp sourceFilePattern destFolder")
    
    @log_time
    def execute(self):
        files = os.listdir()
        files_for_compress = filter(get_filter_function(self.source),files)
        status_elements = map(compress,files_for_compress)
        process_count = reduce(count, status_elements)
        print("{} files processed.".format(process_count))
        

def count(x,y):
    if(type(x)==bool.__class__):
        return 1
    else:
        return x+1
        
def compress(source_file_name):
    dest_file_name = os.getcwd()+"/temp/"+source_file_name+".gz"
    #print("Compressing file: {} to {}".format(source_file_name,dest_file_name))
    with open(source_file_name, mode='rb') as source_file, gzip.open(dest_file_name, 'wb') as dest_file :
        dest_file.writelines(source_file)
    return True
        
def get_filter_function(pattern):
    def pattern_filter(file_name):
        if os.path.isdir(file_name): 
            return False
        match_obj = re.match(pattern,file_name)
        if match_obj:
            return True
        else:
            return False
    return pattern_filter
    
class ThreadPool:
    def __init__(self,N) :
        self.workerQueue = Queue()
        self.workerThreads = [None] * N
        #Start N Threads and keep them running
        for i in range(N) :
            self.workerThreads[i] = self.Worker(self.workerQueue)
            self.workerThreads[i].start()
 
    def addTask(self,runner):
        try :
            self.workerQueue.put(runner)
        except: 
            pass
        
    class Worker(Thread):
        def __init__(self, workerQueue):
            Thread.__init__(self)
            self.workerQueue = workerQueue
            
        def run(self):
            while True :
                runner = self.workerQueue.get()
                runner()

while True:
    command = input("> ")
    cf = CommandFactory()
    command = cf.get_command(command)
    command.execute()
    #exec_function = get_command(command)
    #exec_function()