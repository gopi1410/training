#----------------------------
# Create a class for phone record and store this class in the dictionary
#----------------------------
import re
phone_book = {}
phone_book_file = open("phonebook.csv", mode='a+')

class PhoneRecord:
    def __init__(self,name,number,address) :
        self.name = name
        self.number = number
        self.address = address
        
    def __str__(self):
        s = "Name: {}, Number: {}, Address: {}".format(self.name,self.number,self.address)
        return s
def search_phone_book():
    search_string = input("Enter name or part of a name to search: ")
    for name in phone_book:
        matchObj = re.match(".*{}.*".format(search_string), name)
        if matchObj:
            print(phone_book[name])
            
def add_phone_book_entry():
    entryInput = input("Enter name, number and address comma separated: ")
    nameNumberAddress = entryInput.split(sep=",")
    try:
        x = int(nameNumberAddress[1])
    except Exception as e:
        print("Phone number is not a number")
        raise Exception("Number format error for phone number")
    phoneRecord = PhoneRecord(nameNumberAddress[0],nameNumberAddress[1],nameNumberAddress[2])
    phone_book[nameNumberAddress[0]] = phoneRecord
def lookup_phone_book_entry():
    name = input("Enter name to lookup: ")
    if not name in phone_book:
        print("{} does not exist in the phonebook".format(name))
    else:
        phone_record = phone_book[name]
        print(phone_record)
        #print("Number for {} is {}. And address: {}".format(name,phone_record.number,phone_record.address))
def load_phone_book_from_file():
    phone_book_file.seek(0)
    for line in phone_book_file:
        nameNumberAddress = line.split(sep=",")
        phoneRecord = PhoneRecord(nameNumberAddress[0],nameNumberAddress[1],nameNumberAddress[2])
        phone_book[nameNumberAddress[0]] = phoneRecord        
def update_phone_book():
    phone_book_file.seek(0)
    phone_book_file.truncate()
    for name in phone_book:
        line = "{},{},{}\n".format(name,phone_book[name].number,phone_book[name].address)
        print("Writing this line to phonebook: ",line)
        phone_book_file.writelines(line)
        

def exit_prog():
    phone_book_file.close()
    quit()



#load_phone_book_from_file()

while True:
    try:
        print("Choose an action:")
        print("1. Add a phone book entry")
        print("2. Lookup a phone book entry")
        print("3. Exit")
        choice = input("Enter choice: ")
        choice = int(choice)
        if choice==1:
            add_phone_book_entry()
        elif choice==2:
            lookup_phone_book_entry()
        elif choice==3:
            exit_prog()
    except Exception as e:
        pass
        
