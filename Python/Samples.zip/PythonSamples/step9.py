#----------------------------
# use pickling to persist class state
# use the staticmethod decorator to create static methods
# Use the with structure to wrap file handling parts
# Use error handling to find the end of file
#----------------------------

import pickle
from pickle import UnpicklingError
phone_book = {}

class PhoneRecord:
    pickled_file_name = "phonebook.pic2"
    @staticmethod
    def load_from_pickled_file() :
        phone_book_list = []
        with open(PhoneRecord.pickled_file_name, mode='rb') as phone_book_file:
            while True:
                try:
                    phone_record = pickle.load(phone_book_file)
                    phone_book_list.append(phone_record)
                except (UnpicklingError, EOFError):
                    break
        return phone_book_list
    @staticmethod
    def save_pickled(phone_book_list):
        with open(PhoneRecord.pickled_file_name, mode='wb+') as phone_book_file:
            for phone_record in phone_book_list:
                pickle.dump(phone_record,phone_book_file)
    
    def __init__(self,name,number,address) :
        self.name = name
        self.number = number
        self.address = address
def load_phone_book_from_file():
    phone_book_list = PhoneRecord.load_from_pickled_file()
    for phone_record in phone_book_list:
        phone_book[phone_record.name] = phone_record
        
def update_phone_book():
    phone_book_list = []
    for name in phone_book:
        phone_book_list.append(phone_book[name])
    PhoneRecord.save_pickled(phone_book_list)
def add_phone_book_entry():
    entryInput = input("Enter name, number and address comma separated: ")
    nameNumberAddress = entryInput.split(sep=",")
    phoneRecord = PhoneRecord(nameNumberAddress[0],nameNumberAddress[1],nameNumberAddress[2])
    phone_book[nameNumberAddress[0]] = phoneRecord

def lookup_phone_book_entry():
    name = input("Enter name to lookup: ")
    if not name in phone_book:
        print("{} does not exist in the phonebook".format(name))
    else:
        phoneRecord = phone_book[name]
        print(phoneRecord)
        #print("Number for {} is {}. And address: {}".format(name,phoneRecord.number,phoneRecord.address))

def exit_prog():
    update_phone_book()
    quit()

load_phone_book_from_file()

while True:
    print("Choose an action:")
    print("1. Add a phone book entry")
    print("2. Lookup a phone book entry")
    print("3. Exit")
    choice = input("Enter choice: ")
    choice = int(choice)
    if choice==1:
        add_phone_book_entry()
    elif choice==2:
        lookup_phone_book_entry()
    elif choice==3:
        exit_prog()