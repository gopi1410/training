#----------------------------
# use shelves instead of pickles
# shelf flag
#Value     Meaning
#'r'     Open existing shelf for reading only (default)
#'w'     Open existing shelf for reading and writing
#'c'     Open shelf for reading and writing, creating it if it doesn’t exist
#'n'     Always create a new, empty shelf, open for reading and writing
#----------------------------

import shelve



phone_book_shelf = shelve.open('phonebook.shelf', 'c')

class PhoneRecord:
    
    def __init__(self,name,number,address) :
        self.name = name
        self.number = number
        self.address = address
        

def add_phone_book_entry():
    entryInput = input("Enter name, number and address comma separated: ")
    nameNumberAddress = entryInput.split(sep=",")
    phoneRecord = PhoneRecord(nameNumberAddress[0],nameNumberAddress[1],nameNumberAddress[2])
    phone_book_shelf[nameNumberAddress[0]] = phoneRecord

def lookup_phone_book_entry():
    name = input("Enter name to lookup: ")
    if not name in phone_book_shelf:
        print("{} does not exist in the phonebook".format(name))
    else:
        numberAdress = phone_book_shelf[name]
        print("Number for {} is {}. And address: {}".format(name,numberAdress.number,numberAdress.address))

def exit_prog():
    phone_book_shelf.close()
    quit()

        
def update_phone_book():
    phone_book_list = []
    for name in phone_book_shelf:
        phone_book_list.append(phone_book_shelf[name])
        

while True:
    print("Choose an action:")
    print("1. Add a phone book entry")
    print("2. Lookup a phone book entry")
    print("3. Exit")
    choice = input("Enter choice: ")
    choice = int(choice)
    if choice==1:
        add_phone_book_entry()
    elif choice==2:
        lookup_phone_book_entry()
    elif choice==3:
        exit_prog()