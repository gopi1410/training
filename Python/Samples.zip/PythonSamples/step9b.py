#----------------------------
# Dump objects to a json file
# help: https://docs.python.org/3/library/json.html
#----------------------------

import json

phone_book = {}


class PhoneRecord:
    pickled_file_name = "phonebook.csv"

    def __str__(self):
        return "Number for {} is {}. And address: {}".format(self.name,self.number,self.address)
    
    @staticmethod
    def to_json(phone_record):
        return {'__class__': 'PhoneRecord',
                    '__value__': phone_record.__dict__}   
        
    @staticmethod   
    def from_json(json_object):
        if '__class__' in json_object:
            if json_object['__class__'] == 'PhoneRecord':
                pr = PhoneRecord()
                pr.__dict__ = json_object['__value__']
                return pr;
        else:
            return json_object    
    
    @staticmethod
    def load_from_pickled_file() :
        phone_book_list = []
        with open("phonebook.json", mode='r') as phone_book_file:
            while True:
                try:
                    line = phone_book_file.readline()
                    if not line:
                        break
                    else:
                        phone_record = json.loads(line, object_hook=PhoneRecord.from_json)
                        phone_book_list.append(phone_record)
                except (ValueError, EOFError) as e:
                    break
        return phone_book_list
    
    @staticmethod
    def save_pickled(phone_book_list):
        with open("phonebook.json", mode='w+') as phone_book_file:
            for phone_record in phone_book_list:
                json.dump(phone_record, phone_book_file, default=PhoneRecord.to_json)
                print(file=phone_book_file)
    
    def __init__(self, name="", number="", address="") :
        self.name = name
        self.number = number
        self.address = address
    

def add_phone_book_entry():
    entryInput = input("Enter name, number and address comma separated: ")
    nameNumberAddress = entryInput.split(sep=",")
    phoneRecord = PhoneRecord(nameNumberAddress[0], nameNumberAddress[1], nameNumberAddress[2])
    phone_book[nameNumberAddress[0]] = phoneRecord

def lookup_phone_book_entry():
    name = input("Enter name to lookup: ")
    if not name in phone_book:
        print("{} does not exist in the phonebook".format(name))
    else:
        numberAdress = phone_book[name]
        print("Number for {} is {}. And address: {}".format(name, numberAdress.number, numberAdress.address))

def exit_prog():
    update_phone_book()
    quit()


def load_phone_book_from_file():
    phone_book_list = PhoneRecord.load_from_pickled_file()
    for phone_record in phone_book_list:
        phone_book[phone_record.name] = phone_record
        
def update_phone_book():
    phone_book_list = []
    for name in phone_book:
        phone_book_list.append(phone_book[name])
    PhoneRecord.save_pickled(phone_book_list)
        

load_phone_book_from_file()

while True:
    print("Choose an action:")
    print("1. Add a phone book entry")
    print("2. Lookup a phone book entry")
    print("3. Exit")
    choice = input("Enter choice: ")
    choice = int(choice)
    if choice == 1:
        add_phone_book_entry()
    elif choice == 2:
        lookup_phone_book_entry()
    elif choice == 3:
        exit_prog()
