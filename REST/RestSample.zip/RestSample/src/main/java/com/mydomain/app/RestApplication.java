package com.mydomain.app;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.mydomain.resources.FileResource;
import com.mydomain.resources.OrderResource;
import com.mydomain.resources.UserResource;
import com.mydomain.utils.CSVWriter;
import com.mydomain.utils.ConvertersProvider;

@ApplicationPath("/services")
public class RestApplication extends Application {
	private Set<Object> singletons = new HashSet<Object>();
	private Set<Class<?>> empty = new HashSet<Class<?>>();

	public RestApplication() {
		singletons.add(new UserResource());
		singletons.add(new OrderResource(null));
		//singletons.add(new FileResource());
		singletons.add(new ConvertersProvider());
		singletons.add(new CSVWriter());
	}

	@Override
	public Set<Class<?>> getClasses() {
		return empty;
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}
	
}
