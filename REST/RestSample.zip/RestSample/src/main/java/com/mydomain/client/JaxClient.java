package com.mydomain.client;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import com.mydomain.model.User;

public class JaxClient {
	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
//		User u = new User();
//		u.setName("Fernando");
//		u.setAge(22);
//		Entity entity = Entity.entity(u, MediaType.APPLICATION_JSON);
//		WebTarget target = client
//				.target("http://localhost:8080/RestSample/services/users");
//		Response res = target.request()
//				.header("content-type", "application/json")
//				.accept(MediaType.APPLICATION_JSON).put(entity);
//		Object respObject = res.getEntity();
//		System.out.println(respObject);
		HttpAuthenticationFeature feature = HttpAuthenticationFeature.basic("admin", "admin123");
		WebTarget target = client.register(feature)
				.target("http://localhost:8080/RestSample/services/users");
		Response res = target.request()
				.accept(MediaType.APPLICATION_JSON).get();
		System.out.println(res.toString());
		res.bufferEntity();
		List<User> u = res.readEntity(List.class);
		System.out.println(u);
		

	}
}
