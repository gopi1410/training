package com.mydomain.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.mydomain.app.HibernateUtil;
import com.mydomain.model.Order;
import com.mydomain.model.Product;

@Path("/orders")
public class OrderResource {
	
	private Integer userId;
	
	public OrderResource(Integer userId){
		this.userId=userId;
	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public List<Order> getOrders() {
		Session ses = HibernateUtil.currentSession();
		try {
			Criteria crit = ses.createCriteria(Order.class);
			crit.add(Restrictions.eq("userId", userId));
			return crit.list();
		} finally {
			HibernateUtil.closeSession();
		}
	}
	
	@GET
	@Path("/{orderId}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Order getOrders(@PathParam("orderId") Integer orderId) {
		Session ses = HibernateUtil.currentSession();
		try {
			Criteria crit = ses.createCriteria(Order.class);
			crit.add(Restrictions.eq("id", orderId));
			return (Order)crit.uniqueResult();
		} finally {
			HibernateUtil.closeSession();
		}
	}
	
	@POST
	@Consumes({ MediaType.APPLICATION_FORM_URLENCODED })
	public void createOrder(@FormParam("prodId") Product p, @FormParam("uid") Integer uid){
		Order o = new Order();
		o.setUserId(uid);
		o.setShipToAddress("Bangalore");
		o.getProducts().add(p);
		Transaction tx = HibernateUtil.currentSession().beginTransaction();
		HibernateUtil.currentSession().save(o);
		tx.commit();
	}

}

