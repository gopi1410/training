package com.mydomain.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Collection;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;

import org.apache.commons.beanutils.BeanMap;

@Provider
@Produces("application/vnd.csv+csv")
public class CSVWriter implements MessageBodyWriter<Object>{

	@Override
	public long getSize(Object obj, Class<?> objClass, Type objType,
			Annotation[] annotations, MediaType mediaType) {
		System.out.println("Get size: "+obj+" objClass: "+objClass+" objType: "+objType+" annotations: "+annotations+" mediatype: "+mediaType);
		return 3;
	}

	@Override
	public boolean isWriteable(Class<?> objClass, Type objType, Annotation[] annotations,
			MediaType mediaType) {
		System.out.println("Is Writable objClass: "+objClass+" objType: "+objType+" annotations: "+annotations+" mediatype: "+mediaType.getType()+mediaType.getSubtype());
		if((mediaType.getType()+"/"+mediaType.getSubtype()).equals("application/vnd.csv+csv"))
			return true;
		return false;
	}

	@Override
	public void writeTo(Object obj, Class<?> objClass, Type objType,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> dataMap, OutputStream os)
			throws IOException, WebApplicationException {
		System.out.println("Write To: "+obj+" objClass: "+objClass+" objType: "+objType+" annotations: "+annotations+" mediatype: "+mediaType);
		String ret = "";
		if(obj instanceof Collection){
			Collection data = (Collection)obj;
			for (Object object : data) {
				String line="";
				BeanMap map = new BeanMap(object);
				for (Object key : map.keySet()) {
					Object value = map.get(key);
					System.out.println(value);
					line+=value+",";
				}
				ret+=line+"\n";
			}
		}
		os.write(ret.getBytes());
	}

	
}
