package com.mydomain.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.ext.ParamConverter;
import javax.ws.rs.ext.ParamConverterProvider;
import javax.ws.rs.ext.Provider;

import com.mydomain.model.Product;

@Provider
public class ConvertersProvider implements ParamConverterProvider{

	public ConvertersProvider() {
		System.out.println("Creating the converters provider");
	}
	private final ProductConverter productConverter = new ProductConverter();
	public <T> ParamConverter<T> getConverter(Class<T> rawType, Type genericType,
			Annotation[] annotations) {
		System.out.println("Converting "+rawType+" for "+genericType);
		if(rawType.equals(Product.class))
			return (ParamConverter<T>)productConverter;
		return null;
	}

}
