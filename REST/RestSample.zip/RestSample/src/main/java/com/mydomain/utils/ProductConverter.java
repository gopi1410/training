package com.mydomain.utils;

import javax.ws.rs.ext.ParamConverter;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.mydomain.app.HibernateUtil;
import com.mydomain.model.Product;

public class ProductConverter implements ParamConverter<Product>{

	public Product fromString(String id) {
		System.out.println("Building product from an id");
		Session ses = HibernateUtil.currentSession();
		try {
			Criteria crit = ses.createCriteria(Product.class);
			crit.add(Restrictions.idEq(Integer.parseInt(id)));
			Product p = (Product) crit.uniqueResult();
			System.out.println("Got product: "+p);
			return p;
		} catch(Exception e){
			e.printStackTrace();
		}finally {
			HibernateUtil.closeSession();
		}
		return null;
	}

	public String toString(Product prod) {
		System.out.println("Converting product to string");
		return null;
	}

}
